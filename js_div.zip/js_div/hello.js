function funcao() {
    alert("Teste"); // Exibir mensagem
    confirm('Voce tem certeza?'); // Caixa de confirmação
    prompt('Digite um valor'); // Caixa de entrada de dados
}
